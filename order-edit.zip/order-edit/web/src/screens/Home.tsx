import { useMemo, useState } from 'react';
import { formatCurrency, formatDate, formatMasked, formatPercent } from '../lib/format';
import { businessComparison, dashboardMetrics, monthlyTrend, outstandingOrders, productSalesStats } from '../lib/metrics';
import { useApp } from '../state/AppContext';
import type { Route } from '../state/useRoute';
import type { TxView } from '../types';
import { BusinessBadge, StatusBadge } from '../ui/Badges';
import { BusinessComparisonCard, PaidVsUnpaidCard, ProductSalesBreakdownCard, SalesAndProfitTrendChart } from '../ui/Charts';
import { BusinessFilterChips, PeriodChips } from '../ui/Chips';
import { Icon } from '../ui/Icon';
import { useOrderFlows } from '../ui/OrderFlows';
import { MetricCard } from '../ui/MetricCard';
import { ActionBar, Pill } from '../ui/Pill';
import { TransactionDetail } from '../ui/TransactionDetail';
import { usePdf } from '../ui/usePdf';

const CYAN = '#00B8F0';
const VIOLET = '#A78BFA';
const PAID = '#22C55E';
const PENDING = '#F59E0B';

function GettingStarted({ hasBusiness, hasProduct, hasSale }: { hasBusiness: boolean; hasProduct: boolean; hasSale: boolean }) {
  const steps = [
    { title: 'Add your first business', text: 'Name, order prefix, colour and how profit is calculated.', done: hasBusiness },
    { title: 'Add your products or services', text: 'Selling prices and costs power profit estimates.', done: hasProduct },
    { title: 'Record your first sale', text: 'Create an order to see sales, profit and balances.', done: hasSale },
  ];
  return (
    <section className="card stack12" aria-label="Getting started" data-testid="getting_started_card" style={{ borderRadius: 20 }}>
      <h2>Welcome to aMACEzing Sales</h2>
      <p className="detail">Set up your business in three quick steps. Your numbers appear here once you record sales.</p>
      {steps.map((s, i) => (
        <div key={s.title} className="row gap8" style={{ gap: 12 }}>
          <div
            style={{ width: 28, height: 28, borderRadius: '50%', display: 'grid', placeItems: 'center', flex: 'none', background: s.done ? 'rgba(34,197,94,0.2)' : 'var(--elevated)' }}
          >
            {s.done ? <Icon name="check_circle" size={20} color={PAID} /> : <span style={{ fontSize: 12, fontWeight: 700 }}>{i + 1}</span>}
          </div>
          <div className="grow">
            <div style={{ fontSize: 13, fontWeight: 600 }}>{s.title}</div>
            <div className="detail" style={{ fontSize: 11 }}>{s.text}</div>
          </div>
        </div>
      ))}
      <p className="detail">Adding and editing records is done in the Android app for now.</p>
    </section>
  );
}

function TxLine({ tx, onOpen, onPay, outstanding }: { tx: TxView; onOpen: () => void; onPay?: () => void; outstanding?: boolean }) {
  const { businesses, maskProfit } = useApp();
  return (
    <div className="card tap" style={{ borderRadius: 16, padding: 12 }} onClick={onOpen} data-testid={`${outstanding ? 'outstanding_item' : 'recent_order'}_${tx.orderNumber}`}>
      <div className="row between" style={{ gap: 12 }}>
        <div className="grow">
          <div className="row gap6" style={{ flexWrap: 'wrap' }}>
            <strong style={{ fontSize: 13 }}>{tx.orderNumber}</strong>
            <BusinessBadge businessKey={tx.businessKey} businesses={businesses} />
            {!outstanding && <StatusBadge status={tx.paymentStatus} />}
          </div>
          <div style={{ fontSize: 14, fontWeight: outstanding ? 500 : 600 }}>{tx.customerName}</div>
          <div className="detail" style={{ fontSize: 11 }}>
            {outstanding
              ? `Net: ${formatCurrency(tx.netSales)} • Paid: ${formatCurrency(tx.amountPaid)}`
              : formatDate(tx.orderDateEpochMillis)}
          </div>
        </div>
        <div className="right">
          {outstanding ? (
            <strong style={{ fontSize: 14, color: PENDING }}>{formatCurrency(tx.outstandingBalance)}</strong>
          ) : (
            <>
              <strong style={{ fontSize: 14, color: CYAN }}>{formatCurrency(tx.netSales)}</strong>
              <div style={{ fontSize: 11, color: PENDING }}>Profit: {formatMasked(tx.estimatedProfit, maskProfit)}</div>
            </>
          )}
        </div>
      </div>
      {outstanding && (
        <div onClick={(e) => e.stopPropagation()}>
          <ActionBar>
            <Pill label="Details" icon="receipt" onClick={onOpen} testId={`outstanding_details_${tx.orderNumber}`} />
            {onPay && <Pill label="Pay" icon="payment" onClick={onPay} testId={`quick_pay_${tx.orderNumber}`} />}
          </ActionBar>
        </div>
      )}
    </div>
  );
}

export function HomeScreen({ go }: { go: (r: Route) => void }) {
  const { businesses, products, transactions, filtered, maskProfit, setStatus } = useApp();
  const [viewing, setViewing] = useState<TxView | null>(null);
  const flows = useOrderFlows();
  const pdf = usePdf();

  const metrics = useMemo(() => dashboardMetrics(filtered), [filtered]);
  const trend = useMemo(() => monthlyTrend(filtered), [filtered]);
  const comparison = useMemo(() => businessComparison(filtered, businesses), [filtered, businesses]);
  const productStats = useMemo(() => productSalesStats(filtered), [filtered]);
  const outstanding = useMemo(() => outstandingOrders(filtered), [filtered]);

  const marginText = maskProfit ? '••••' : formatPercent(metrics.profitMarginPercent);

  return (
    <>
      {(businesses.length === 0 || products.length === 0 || transactions.length === 0) && (
        <GettingStarted hasBusiness={businesses.length > 0} hasProduct={products.length > 0} hasSale={transactions.length > 0} />
      )}

      <div style={{ height: 8 }} />
      <BusinessFilterChips />
      <PeriodChips />

      <div className="grid2">
        <MetricCard title="Gross Sales" value={formatCurrency(metrics.grossSales)} icon="shopping_bag" color={CYAN} />
        <MetricCard title="Discounts" value={formatCurrency(metrics.totalDiscounts)} icon="discount" color={PENDING} />
        <MetricCard title="Avg Order" value={formatCurrency(metrics.averageOrderValue)} icon="receipt" color={CYAN} />
        <MetricCard
          title="Top Customer"
          value={metrics.topCustomerName || '—'}
          icon="emoji_events"
          color={PENDING}
          subtitle={metrics.topCustomerName ? formatCurrency(metrics.topCustomerSales) : undefined}
          subtitleColor={PENDING}
        />
      </div>
      <div className="grid2">
        <MetricCard
          title="Net Sales"
          value={formatMasked(metrics.netSales, maskProfit)}
          icon="attach_money"
          color={VIOLET}
          subtitle={`${metrics.ordersCount} orders recorded`}
          subtitleColor={CYAN}
        />
        <MetricCard
          title="Estimated Profit"
          value={formatMasked(metrics.estimatedProfit, maskProfit)}
          icon="show_chart"
          color={VIOLET}
          subtitle={`Margin: ${marginText}`}
          subtitleColor={VIOLET}
        />
      </div>
      <div className="grid2">
        <MetricCard title="Collected Cash" value={formatCurrency(metrics.totalCollected)} icon="payments" color={PAID} subtitle="Paid into account" subtitleColor={PAID} />
        <MetricCard title="Outstanding" value={formatCurrency(metrics.outstandingReceivables)} icon="warning" color={PENDING} subtitle="Receivables to collect" subtitleColor={PENDING} />
      </div>

      <div className="cardgrid charts">
        <SalesAndProfitTrendChart data={trend} masked={maskProfit} />
        <BusinessComparisonCard rows={comparison} masked={maskProfit} />
        <ProductSalesBreakdownCard stats={productStats} />
        <PaidVsUnpaidCard collected={metrics.totalCollected} outstanding={metrics.outstandingReceivables} />
      </div>

      {outstanding.length > 0 && (
        <>
          <div className="row between">
            <h2 className="section-title">Outstanding Receivables ({outstanding.length})</h2>
            <button
              type="button"
              className="pill quiet"
              style={{ flex: 'none', padding: '0 12px', color: 'var(--cyan)', background: 'transparent' }}
              onClick={() => {
                setStatus('PENDING');
                go('sales');
              }}
            >
              View All
            </button>
          </div>
          <div className="cardgrid">
            {outstanding.slice(0, 4).map((tx) => (
              <TxLine key={tx.id} tx={tx} outstanding onOpen={() => setViewing(tx)} onPay={() => flows.openPay(tx)} />
            ))}
          </div>
        </>
      )}

      <div className="row between">
        <h2 className="section-title">Recent Transactions</h2>
        <button
          type="button"
          className="pill quiet"
          style={{ flex: 'none', padding: '0 12px', color: 'var(--cyan)', background: 'transparent' }}
          onClick={() => go('sales')}
        >
          See All ({filtered.length})
        </button>
      </div>
      {filtered.length === 0 ? (
        <div className="card panel" style={{ border: '1px solid var(--border)', background: 'var(--elevated)', borderRadius: 16 }}>
          <div style={{ fontWeight: 500 }}>No transactions recorded yet.</div>
          <div className="detail" style={{ marginTop: 6 }}>Create an order in the Android app to begin.</div>
        </div>
      ) : (
        <div className="cardgrid">{filtered.slice(0, 5).map((tx) => <TxLine key={tx.id} tx={tx} onOpen={() => setViewing(tx)} />)}</div>
      )}

      {viewing && (
        <TransactionDetail
          tx={viewing}
          businesses={businesses}
          masked={maskProfit}
          onClose={() => setViewing(null)}
          onEdit={() => { flows.openEdit(viewing); setViewing(null); }}
          onPay={() => { flows.openPay(viewing); setViewing(null); }}
          onDelete={() => { flows.askDelete(viewing); setViewing(null); }}
          onPdf={() => pdf.receipt(viewing)}
          onSharePdf={() => pdf.receipt(viewing, true)}
          pdfBusy={pdf.busy}
        />
      )}
      {flows.dialogs}
    </>
  );
}
