import { useMemo, useState } from 'react';
import { formatCurrency, formatDate, formatMasked } from '../lib/format';
import { useApp } from '../state/AppContext';
import type { TxView } from '../types';
import { BusinessBadge, STATUS_ORDER, StatusBadge, statusLabel } from '../ui/Badges';
import { BusinessFilterChips, FilterChip, PeriodChips } from '../ui/Chips';
import { Icon } from '../ui/Icon';
import { Fab } from '../ui/Fab';
import { useOrderFlows } from '../ui/OrderFlows';
import { ActionBar, Pill } from '../ui/Pill';
import { TransactionDetail } from '../ui/TransactionDetail';
import { usePdf } from '../ui/usePdf';

export function SalesScreen() {
  const { businesses, filtered, filters, maskProfit, setSearch, setStatus } = useApp();
  const [sortByDateDesc, setSortByDateDesc] = useState(true);
  const [viewing, setViewing] = useState<TxView | null>(null);
  const flows = useOrderFlows();
  const pdf = usePdf();

  const list = useMemo(() => {
    const query = filters.search.trim().toLowerCase();
    const matching = filtered.filter((tx) => {
      if (filters.status !== null && tx.paymentStatus !== filters.status) return false;
      if (!query) return true;
      return (
        tx.orderNumber.toLowerCase().includes(query) ||
        tx.customerName.toLowerCase().includes(query) ||
        tx.remarks.toLowerCase().includes(query) ||
        tx.lineItems.some((l) => l.productName.toLowerCase().includes(query))
      );
    });
    return [...matching].sort((a, b) =>
      sortByDateDesc ? b.orderDateEpochMillis - a.orderDateEpochMillis : b.netSales - a.netSales,
    );
  }, [filtered, filters.search, filters.status, sortByDateDesc]);

  return (
    <>
      <div style={{ height: 8 }} />
      <div>
        <h2 className="page-title">Sales Transactions</h2>
        <p className="subtitle">{list.length} orders matching filters</p>
      </div>

      <BusinessFilterChips />
      <PeriodChips />

      <div className="fieldwrap">
        <Icon name="search" />
        <input
          className="field"
          type="search"
          inputMode="search"
          placeholder="Search by Order #, Customer, or Product..."
          value={filters.search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search orders"
          data-testid="transactions_search_input"
        />
        {filters.search && (
          <button type="button" className="icon-btn clear" onClick={() => setSearch('')} aria-label="Clear search">
            <Icon name="clear" />
          </button>
        )}
      </div>

      <div className="chip-row" role="group" aria-label="Payment status and sort">
        <FilterChip label="All Statuses" selected={filters.status === null} onClick={() => setStatus(null)} testId="status_filter_all" />
        {STATUS_ORDER.map((st) => (
          <FilterChip key={st} label={statusLabel(st)} selected={filters.status === st} onClick={() => setStatus(st)} testId={`status_filter_${st.toLowerCase()}`} />
        ))}
        <span style={{ width: 8, flex: 'none' }} />
        <FilterChip
          label={sortByDateDesc ? 'Sort: Date ↓' : 'Sort: Net Sales ↓'}
          selected={!sortByDateDesc}
          icon="filter_list"
          onClick={() => setSortByDateDesc((v) => !v)}
        />
      </div>

      {list.length === 0 ? (
        <div className="card panel">
          <div style={{ fontWeight: 500 }}>No transactions match the criteria.</div>
          <div className="detail" style={{ marginTop: 4 }}>Try clearing the search query or status filter.</div>
        </div>
      ) : (
        <div className="cardgrid">{list.map((tx) => {
          const items = tx.lineItems.map((l) => `${l.productName} (x${l.quantity})`).join(', ');
          return (
            <article key={tx.id} className="card flat tap" onClick={() => setViewing(tx)} data-testid={`tx_card_${tx.orderNumber}`}>
              <div className="row between">
                <div className="row gap6">
                  <strong style={{ fontSize: 14 }}>{tx.orderNumber}</strong>
                  <BusinessBadge businessKey={tx.businessKey} businesses={businesses} />
                </div>
                <StatusBadge status={tx.paymentStatus} />
              </div>
              <div className="row between" style={{ marginTop: 6, gap: 8 }}>
                <span style={{ fontSize: 15, fontWeight: 600 }}>{tx.customerName}</span>
                <span className="detail">{formatDate(tx.orderDateEpochMillis)}</span>
              </div>
              {items && <div className="detail" style={{ marginTop: 2 }}>{items}</div>}
              <div className="row between" style={{ marginTop: 8, alignItems: 'flex-end' }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--cyan)' }}>Net: {formatCurrency(tx.netSales)}</div>
                  <div style={{ fontSize: 12, color: 'var(--pending)' }}>Profit: {formatMasked(tx.estimatedProfit, maskProfit)}</div>
                </div>
                <div className="right">
                  <div style={{ fontSize: 12, color: 'var(--paid)' }}>Paid: {formatCurrency(tx.amountPaid)}</div>
                  {tx.outstandingBalance > 0 && (
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--pending)' }}>Bal: {formatCurrency(tx.outstandingBalance)}</div>
                  )}
                </div>
              </div>
              <div onClick={(e) => e.stopPropagation()}>
                <ActionBar>
                  <Pill label="Details" icon="receipt" onClick={() => setViewing(tx)} testId={`tx_details_btn_${tx.orderNumber}`} />
                  {tx.outstandingBalance > 0 && tx.paymentStatus !== 'CANCELLED' && (
                    <Pill label="Pay" icon="payment" onClick={() => flows.openPay(tx)} testId={`tx_pay_btn_${tx.orderNumber}`} />
                  )}
                  <Pill label="Edit" icon="edit" onClick={() => flows.openEdit(tx)} testId={`tx_edit_btn_${tx.orderNumber}`} />
                  <Pill label="Delete" icon="delete" danger onClick={() => flows.askDelete(tx)} testId={`tx_delete_btn_${tx.orderNumber}`} />
                </ActionBar>
              </div>
            </article>
          );
        })}</div>
      )}

      {viewing && (
        <TransactionDetail
          tx={viewing}
          businesses={businesses}
          masked={maskProfit}
          onClose={() => setViewing(null)}
          onEdit={() => { flows.openEdit(viewing); setViewing(null); }}
          onPay={() => { flows.openPay(viewing); setViewing(null); }}
          onDelete={() => { flows.askDelete(viewing); setViewing(null); }}
          onPdf={() => pdf.receipt(viewing)}
          onSharePdf={() => pdf.receipt(viewing, true)}
          pdfBusy={pdf.busy}
        />
      )}
      <Fab label="New order" onClick={flows.openNew} testId="new_order_fab" />
      {flows.dialogs}
    </>
  );
}
