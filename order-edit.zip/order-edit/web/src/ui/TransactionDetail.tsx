import type { ResolvedBusiness } from '../lib/businesses';
import { formatCurrency, formatDate, formatMasked, formatPercent } from '../lib/format';
import type { TxView } from '../types';
import { BusinessBadge, StatusBadge } from './Badges';
import { Dialog } from './Dialog';
import { ActionBar, Pill } from './Pill';
import { canSharePdf } from './usePdf';

function Row({ label, value, color, big }: { label: string; value: string; color?: string; big?: boolean }) {
  return (
    <div className={`sumrow${big ? ' big' : ''}`}>
      <span style={{ color: big ? 'var(--text)' : 'var(--text2)' }}>{label}</span>
      <span style={{ color: color ?? 'var(--text)', fontWeight: big ? 700 : 500 }}>{value}</span>
    </div>
  );
}

/** Read-only order details: same sections and wording as the Android details dialog. */
export function TransactionDetail({
  tx,
  businesses,
  masked,
  onClose,
  onEdit,
  onPay,
  onDelete,
  onPdf,
  onSharePdf,
  pdfBusy,
}: {
  tx: TxView;
  businesses: ResolvedBusiness[];
  masked: boolean;
  onClose: () => void;
  onEdit?: () => void;
  onPay?: () => void;
  onDelete?: () => void;
  /** Download / share the sales receipt PDF. */
  onPdf?: () => void;
  onSharePdf?: () => void;
  pdfBusy?: boolean;
}) {
  const margin = tx.netSales > 0 ? (tx.estimatedProfit / tx.netSales) * 100 : 0;
  const discountLabel = tx.discountType === 'PERCENTAGE' && tx.discountPercentage > 0 ? `Discount (${formatPercent(tx.discountPercentage)})` : 'Discount';
  return (
    <Dialog
      title={tx.orderNumber}
      onClose={onClose}
      header={
        <div className="stack8">
          <h2 className="dtitle">{tx.orderNumber}</h2>
          <div className="row gap8">
            <BusinessBadge businessKey={tx.businessKey} businesses={businesses} />
            <StatusBadge status={tx.paymentStatus} />
          </div>
          <span className="muted">{formatDate(tx.orderDateEpochMillis)}</span>
        </div>
      }
      footer={
        <>
          {onEdit && <Pill label="Edit" icon="edit" wide onClick={onEdit} testId="detail_edit_button" />}
          {onPay && tx.outstandingBalance > 0 && tx.paymentStatus !== 'CANCELLED' && <Pill label="Pay" icon="payment" wide onClick={onPay} testId="detail_pay_button" />}
          {onDelete && <Pill label="Delete" icon="delete" danger wide onClick={onDelete} testId="detail_delete_button" />}
          <Pill label="Close" icon="close" quiet wide onClick={onClose} />
        </>
      }
    >
      <hr className="sep" />
      <div className="stack8">
        <span className="label">Customer</span>
        <strong style={{ fontSize: 18, fontWeight: 500 }}>{tx.customerName}</strong>
      </div>

      <div className="stack8">
        <span className="label">Products Ordered ({tx.lineItems.length})</span>
        <div className="lines">
          {tx.lineItems.map((line, i) => (
            <div key={`${line.productName}-${i}`}>
              <div>
                <div style={{ fontWeight: 500 }}>{line.productName}</div>
                <div className="detail">
                  {line.quantity} × {formatCurrency(line.unitSellingPrice)}
                </div>
              </div>
              <strong>{formatCurrency(line.lineSubtotal)}</strong>
            </div>
          ))}
        </div>
      </div>

      <div className="sumbox">
        <Row label="Gross Sales" value={formatCurrency(tx.grossSales)} />
        <Row label={discountLabel} value={`-${formatCurrency(tx.discountAmount)}`} color="var(--pending)" />
        <Row label="Net Sales" value={formatCurrency(tx.netSales)} color="var(--cyan)" big />
        <Row label={`Estimated Profit (${masked ? '••••' : formatPercent(margin)})`} value={formatMasked(tx.estimatedProfit, masked)} />
        <hr className="sep" />
        <Row label="Amount Paid" value={formatCurrency(tx.amountPaid)} color="var(--paid)" />
        <Row label="Outstanding Balance" value={formatCurrency(tx.outstandingBalance)} color={tx.outstandingBalance > 0 ? 'var(--pending)' : 'var(--paid)'} big />
      </div>

      {tx.payments.length > 0 && (
        <div className="stack8">
          <span className="label">Recorded Payments ({tx.payments.length})</span>
          <div className="lines">
            {tx.payments.map((p, i) => (
              <div key={i}>
                <div>
                  <div style={{ fontWeight: 500 }}>
                    {p.paymentMethod}
                    {p.referenceNumber ? ` • Ref: ${p.referenceNumber}` : ''}
                  </div>
                  <div className="detail">{formatDate(p.paymentDateEpochMillis)}</div>
                </div>
                <strong style={{ color: 'var(--paid)' }}>{formatCurrency(p.amount)}</strong>
              </div>
            ))}
          </div>
        </div>
      )}

      {tx.remarks.trim() && (
        <div className="stack8">
          <span className="label">Remarks &amp; Notes</span>
          <p className="muted" style={{ lineHeight: 1.6 }}>{tx.remarks}</p>
        </div>
      )}

      {onPdf && (
        <ActionBar>
          <Pill label={pdfBusy ? 'Creating PDF…' : 'Receipt PDF'} icon="picture_as_pdf" disabled={pdfBusy} onClick={onPdf} testId="detail_receipt_pdf_button" />
          {onSharePdf && canSharePdf() && <Pill label="Share PDF" icon="share" disabled={pdfBusy} onClick={onSharePdf} testId="detail_receipt_share_button" />}
        </ActionBar>
      )}
    </Dialog>
  );
}
