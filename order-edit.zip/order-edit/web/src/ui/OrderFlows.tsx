import { useState, type ReactNode } from 'react';
import { fire } from '../lib/fire';
import { applyPayment } from '../lib/orders';
import { deleteRecord, saveCustomer, saveTransaction } from '../lib/store';
import { useApp } from '../state/AppContext';
import type { TxView } from '../types';
import { ConfirmDialog } from './ConfirmDialog';
import { OrderDialog } from './OrderDialog';
import { OrderEditDialog } from './OrderEditDialog';
import { PaymentDialog } from './PaymentDialog';

type Flow = { kind: 'new' } | { kind: 'edit'; tx: TxView } | { kind: 'pay'; tx: TxView } | { kind: 'delete'; tx: TxView } | null;

/** New order, edit order, record payment and delete order, shared by Home and Sales. Render `dialogs` once in the screen. */
export function useOrderFlows(): {
  openNew: () => void;
  openEdit: (tx: TxView) => void;
  openPay: (tx: TxView) => void;
  askDelete: (tx: TxView) => void;
  dialogs: ReactNode;
} {
  const { user, businesses, products, customers, transactions, filters, maskProfit, notify } = useApp();
  const [flow, setFlow] = useState<Flow>(null);
  const close = () => setFlow(null);
  const editBusiness = flow?.kind === 'edit' ? businesses.find((b) => b.key === flow.tx.businessKey) : undefined;

  const dialogs = (
    <>
      {flow?.kind === 'new' && (
        <OrderDialog
          businesses={businesses}
          products={products}
          customers={customers}
          transactions={transactions}
          defaultBusiness={filters.business}
          masked={maskProfit}
          onClose={close}
          onSave={(tx) => {
            fire(saveTransaction(user.uid, tx), notify, `Order ${tx.orderNumber} saved.`);
            // A new customer name also becomes a customer record, like in the app.
            const known = customers.some((c) => c.name.trim().toLowerCase() === tx.customerName.toLowerCase());
            if (!known) saveCustomer(user.uid, tx.customerName).catch(() => undefined);
            close();
          }}
        />
      )}
      {flow?.kind === 'edit' && editBusiness && (
        <OrderEditDialog
          tx={flow.tx}
          business={editBusiness}
          products={products}
          masked={maskProfit}
          onClose={close}
          onSave={(updated) => {
            fire(saveTransaction(user.uid, updated), notify, `Order ${updated.orderNumber} updated.`);
            close();
          }}
        />
      )}
      {flow?.kind === 'pay' && (
        <PaymentDialog
          tx={flow.tx}
          onClose={close}
          onSave={(payment) => {
            const t = flow.tx;
            fire(saveTransaction(user.uid, { ...t, ...applyPayment(t, payment) }), notify, 'Payment recorded.');
            close();
          }}
        />
      )}
      {flow?.kind === 'delete' && (
        <ConfirmDialog
          title="Delete order?"
          message={`Delete order ${flow.tx.orderNumber} for ${flow.tx.customerName}? This also removes it on your other devices.`}
          confirmLabel="Delete"
          onClose={close}
          onConfirm={() => {
            fire(deleteRecord(user.uid, 'transactions', flow.tx.id), notify, `Order ${flow.tx.orderNumber} deleted.`);
            close();
          }}
        />
      )}
    </>
  );

  return {
    openNew: () => (businesses.length === 0 ? notify('Add a business in the Android app first.') : setFlow({ kind: 'new' })),
    openEdit: (tx) =>
      businesses.some((b) => b.key === tx.businessKey) ? setFlow({ kind: 'edit', tx }) : notify('Add this order’s business back in Settings before editing it.'),
    openPay: (tx) => setFlow({ kind: 'pay', tx }),
    askDelete: (tx) => setFlow({ kind: 'delete', tx }),
    dialogs,
  };
}
