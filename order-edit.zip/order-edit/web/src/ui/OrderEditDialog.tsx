import { useMemo, useState } from 'react';
import type { ResolvedBusiness } from '../lib/businesses';
import { formatCurrency, formatDate, formatMasked, formatPercent } from '../lib/format';
import { buildOrderEdit, orderToEditForm, paidOn, previewOrderEdit, type OrderEditForm, type OrderLineForm } from '../lib/orderBuilder';
import type { TransactionInput } from '../lib/store';
import type { ProductView, TxView } from '../types';
import { statusLabel } from './Badges';
import { Dialog } from './Dialog';
import { FormError, SelectField, Switch, TextField } from './Form';
import { Icon } from './Icon';
import { Pill } from './Pill';

const emptyLine = (): OrderLineForm => ({ productId: '', name: '', quantity: '1', unitPrice: '', unitCost: 0 });

/**
 * Edit an order, like the app: the products, discount and remarks can change and the order can be cancelled. The
 * customer, date and the payments already recorded stay as they are (use Pay to add a payment).
 */
export function OrderEditDialog({
  tx,
  business,
  products,
  masked,
  onSave,
  onClose,
}: {
  tx: TxView;
  business: ResolvedBusiness;
  products: ProductView[];
  masked: boolean;
  onSave: (tx: TransactionInput) => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState<OrderEditForm>(() => orderToEditForm(tx));
  const [error, setError] = useState<string | null>(null);

  const catalog = useMemo(
    () => products.filter((p) => p.businessKey === tx.businessKey && p.isActive).sort((a, b) => a.name.localeCompare(b.name)),
    [products, tx.businessKey],
  );
  const preview = useMemo(() => previewOrderEdit(form, business, tx), [form, business, tx]);
  const paid = paidOn(tx);

  const patch = (over: Partial<OrderEditForm>) => setForm((f) => ({ ...f, ...over }));
  const patchLine = (index: number, over: Partial<OrderLineForm>) =>
    setForm((f) => ({ ...f, lines: f.lines.map((l, i) => (i === index ? { ...l, ...over } : l)) }));

  const pickProduct = (index: number, productId: string) => {
    const p = catalog.find((c) => c.id === productId);
    patchLine(index, p ? { productId, name: p.name, unitPrice: String(p.sellingPrice), unitCost: p.unitCost } : { productId: '', unitCost: 0 });
  };

  const save = () => {
    const result = buildOrderEdit(form, tx, business);
    if (!result.ok) return setError(result.error);
    onSave(result.value);
  };

  return (
    <Dialog
      title={`Edit Order ${tx.orderNumber}`}
      onClose={onClose}
      footer={
        <>
          <Pill label="Cancel" icon="close" quiet wide onClick={onClose} testId="cancel_edit_order_button" />
          <Pill label="Save Changes" icon="check" wide onClick={save} testId="save_order_button" />
        </>
      }
    >
      <div className="sumbox" aria-label="Order details">
        <div className="sumrow"><span className="muted">Business</span><span>{business.name}</span></div>
        <div className="sumrow"><span className="muted">Customer</span><span>{tx.customerName}</span></div>
        <div className="sumrow"><span className="muted">Order date</span><span>{formatDate(tx.orderDateEpochMillis)}</span></div>
        <div className="sumrow"><span className="muted">Paid so far</span><span>{formatCurrency(paid)}</span></div>
      </div>
      <p className="detail">The customer, date and recorded payments stay as they are. Use Pay to add a payment.</p>

      <div className="stack8">
        <span className="label">Products ordered</span>
        {form.lines.map((line, i) => {
          // A product that is no longer in the catalog stays on the order as it is.
          const orphan = line.productId !== '' && !catalog.some((p) => p.id === line.productId);
          return (
            <div className="linebox" key={i}>
              <SelectField
                label="Product"
                value={line.productId}
                onChange={(v) => pickProduct(i, v)}
                options={[
                  { value: '', label: 'Custom item' },
                  ...catalog.map((p) => ({ value: p.id, label: p.name })),
                  ...(orphan ? [{ value: line.productId, label: `${line.name} (not in catalog)` }] : []),
                ]}
              />
              {line.productId === '' && <TextField label="Item name" value={line.name} onChange={(v) => patchLine(i, { name: v })} testId={`edit_item_name_${i}`} />}
              <div className="itemrow">
                <TextField label="Qty" value={line.quantity} onChange={(v) => patchLine(i, { quantity: v })} inputMode="numeric" testId={`edit_item_qty_${i}`} />
                <TextField label="Unit price (₱)" value={line.unitPrice} onChange={(v) => patchLine(i, { unitPrice: v })} inputMode="decimal" testId={`edit_item_price_${i}`} />
                <button
                  type="button"
                  className="icon-btn"
                  onClick={() => setForm((f) => ({ ...f, lines: f.lines.length > 1 ? f.lines.filter((_, k) => k !== i) : [emptyLine()] }))}
                  aria-label="Remove item"
                >
                  <Icon name="delete" size={20} color="var(--cancelled)" />
                </button>
              </div>
            </div>
          );
        })}
        <div>
          <Pill label="Add Product" icon="add" onClick={() => setForm((f) => ({ ...f, lines: [...f.lines, emptyLine()] }))} testId="edit_add_product_line_button" />
        </div>
      </div>

      <div className="itemrow" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <SelectField
          label="Discount type"
          value={form.discountType}
          onChange={(v) => patch({ discountType: v === 'FIXED' ? 'FIXED' : 'PERCENTAGE' })}
          options={[
            { value: 'PERCENTAGE', label: 'Percentage (%)' },
            { value: 'FIXED', label: 'Fixed amount (₱)' },
          ]}
        />
        <TextField label="Discount" value={form.discountValue} onChange={(v) => patch({ discountValue: v })} inputMode="decimal" placeholder="0" />
      </div>
      <label className="fgroup">
        <span className="flabel">Order Remarks / Payment Notes</span>
        <textarea className="finput" value={form.remarks} onChange={(e) => patch({ remarks: e.target.value })} />
      </label>
      <Switch label="Cancel this order" checked={form.cancelled} onChange={(v) => patch({ cancelled: v })} testId="edit_cancel_order_switch" />
      <p className="detail">Without it the status follows the payments: paid, partially paid or pending.</p>

      <div className="sumbox" aria-label="Order totals">
        <div className="sumrow"><span className="muted">Gross Sales</span><span>{formatCurrency(preview.grossSales)}</span></div>
        <div className="sumrow"><span className="muted">Discount</span><span style={{ color: 'var(--pending)' }}>-{formatCurrency(preview.discountAmount)}</span></div>
        <div className="sumrow big"><span>Net Sales</span><span style={{ color: 'var(--cyan)' }}>{formatCurrency(preview.netSales)}</span></div>
        <div className="sumrow"><span className="muted">Estimated Profit ({masked ? '••••' : formatPercent(preview.estimatedMarginPercent)})</span><span>{formatMasked(preview.estimatedProfit, masked)}</span></div>
        <div className="sumrow"><span className="muted">Amount Paid</span><span>{formatCurrency(paid)}</span></div>
        <div className="sumrow"><span className="muted">Outstanding Balance</span><span>{formatCurrency(preview.outstandingBalance)}</span></div>
        <div className="sumrow"><span className="muted">Status after saving</span><span>{statusLabel(preview.resolvedStatus)}</span></div>
      </div>
      <FormError message={error} />
    </Dialog>
  );
}
