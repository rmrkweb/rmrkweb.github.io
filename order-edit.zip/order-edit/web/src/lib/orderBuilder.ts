import type { ResolvedBusiness } from './businesses';
import { calculate, type CalculationResult, type DiscountKind } from './calculator';
import { manilaDateKey, round2 } from './format';
import { nextOrderNumber } from './orders';
import type { TransactionInput } from './store';
import { parseNumber, type Result } from './validation';
import type { TxView } from '../types';

export interface OrderLineForm {
  /** A catalog product id, or '' for a custom item. */
  productId: string;
  name: string;
  quantity: string;
  unitPrice: string;
  /** Cost per unit, taken from the catalog product (0 for custom items). */
  unitCost: number;
}

export interface OrderForm {
  customerName: string;
  /** yyyy-MM-dd */
  dateKey: string;
  lines: OrderLineForm[];
  discountType: DiscountKind;
  discountValue: string;
  initialPayment: string;
  paymentMethod: string;
  remarks: string;
}

/** Today keeps the real time (so orders sort naturally); another day is 12:00 Manila time on that date. */
export function orderDateMillis(dateKey: string, now: number): number {
  if (dateKey === manilaDateKey(now)) return now;
  const [y, m, d] = dateKey.split('-').map(Number);
  return Date.UTC(y, m - 1, d, 4);
}

function readLines(lines: OrderLineForm[]) {
  return lines
    .map((l) => ({ line: l, quantity: parseNumber(l.quantity), price: parseNumber(l.unitPrice) }))
    .filter((l) => l.line.name.trim() !== '' || l.quantity !== null || l.price !== null);
}

/** Live totals for the form while it is being filled in (invalid or empty rows count as zero). */
export function previewOrder(form: OrderForm, business: ResolvedBusiness): CalculationResult {
  const items = readLines(form.lines)
    .filter((l) => l.quantity !== null && l.quantity > 0 && l.price !== null && l.price >= 0)
    .map((l) => ({ quantity: l.quantity as number, unitSellingPrice: l.price as number, unitCost: l.line.unitCost }));
  return calculate(
    { method: business.profitMethod, marginPercent: business.marginPercent, useUnitCostIfAvailable: business.useUnitCostIfAvailable },
    items,
    form.discountType,
    parseNumber(form.discountValue) ?? 0,
    parseNumber(form.initialPayment) ?? 0,
  );
}

export interface OrderContext {
  business: ResolvedBusiness;
  existingOrderNumbers: string[];
  now: number;
  newId: () => string;
}

/** Validates the form and builds the order document, ready to be saved. */
export function buildOrder(form: OrderForm, ctx: OrderContext): Result<TransactionInput> {
  const customerName = form.customerName.trim();
  if (!customerName) return { ok: false, error: 'Customer name is required.' };

  const rows = readLines(form.lines);
  if (rows.length === 0) return { ok: false, error: 'Add at least one product.' };
  for (const r of rows) {
    if (r.line.name.trim() === '') return { ok: false, error: 'Every item needs a product name.' };
    if (r.quantity === null || !Number.isInteger(r.quantity) || r.quantity < 1) return { ok: false, error: `Enter a whole-number quantity of 1 or more for "${r.line.name.trim()}".` };
    if (r.price === null || r.price < 0) return { ok: false, error: `Enter a valid price for "${r.line.name.trim()}".` };
  }

  const discount = form.discountValue.trim() === '' ? 0 : parseNumber(form.discountValue);
  if (discount === null || discount < 0) return { ok: false, error: 'Enter a valid discount.' };
  if (form.discountType === 'PERCENTAGE' && discount > 100) return { ok: false, error: 'A percentage discount can be at most 100%.' };

  const paid = form.initialPayment.trim() === '' ? 0 : parseNumber(form.initialPayment);
  if (paid === null || paid < 0) return { ok: false, error: 'Enter a valid initial payment.' };

  const items = rows.map((r) => ({ quantity: r.quantity as number, unitSellingPrice: r.price as number, unitCost: r.line.unitCost }));
  const calc = calculate(
    {
      method: ctx.business.profitMethod,
      marginPercent: ctx.business.marginPercent,
      useUnitCostIfAvailable: ctx.business.useUnitCostIfAvailable,
    },
    items,
    form.discountType,
    discount,
    paid,
  );
  if (paid > calc.netSales + 0.005) return { ok: false, error: 'The initial payment is more than the net total.' };

  const date = orderDateMillis(form.dateKey, ctx.now);
  const lineItems = rows.map((r) => ({
    productId: Number(r.line.productId) || 0,
    productName: r.line.name.trim(),
    quantity: r.quantity as number,
    unitSellingPrice: r.price as number,
    unitCost: r.line.unitCost,
    lineSubtotal: round2((r.quantity as number) * (r.price as number)),
  }));

  return {
    ok: true,
    value: {
      id: ctx.newId(),
      orderNumber: nextOrderNumber(ctx.business.orderPrefix, date, ctx.existingOrderNumbers),
      businessType: ctx.business.key,
      customerName,
      orderDateEpochMillis: date,
      discountType: form.discountType,
      discountPercentage: form.discountType === 'PERCENTAGE' ? discount : 0,
      discountAmount: calc.discountAmount,
      grossSales: calc.grossSales,
      netSales: calc.netSales,
      totalProductCost: calc.totalProductCost,
      estimatedProfit: calc.estimatedProfit,
      paymentStatus: calc.resolvedStatus,
      amountPaid: round2(paid),
      outstandingBalance: calc.outstandingBalance,
      paymentNotes: '',
      remarks: form.remarks.trim(),
      lineItems,
      payments:
        paid > 0
          ? [{ amount: round2(paid), paymentDateEpochMillis: date, paymentMethod: form.paymentMethod, referenceNumber: '', notes: 'Initial payment upon order creation' }]
          : [],
    },
  };
}

// ---- Editing an order ----
// Like the Android app: the items, discount and remarks can change and an order can be cancelled. The customer, date,
// business, order number and the recorded payments stay as they are; the paid amount comes from the payments, and the
// status follows them (a cancelled order stays cancelled).

export interface OrderEditForm {
  lines: OrderLineForm[];
  discountType: DiscountKind;
  discountValue: string;
  remarks: string;
  cancelled: boolean;
}

/** The edit form for a saved order. */
export function orderToEditForm(tx: TxView): OrderEditForm {
  const percent = tx.discountType !== 'FIXED';
  const discount = percent ? tx.discountPercentage : tx.discountAmount;
  return {
    lines: tx.lineItems.map((l) => ({
      productId: l.productId > 0 ? String(l.productId) : '',
      name: l.productName,
      quantity: String(l.quantity),
      unitPrice: String(l.unitSellingPrice),
      unitCost: l.unitCost,
    })),
    discountType: percent ? 'PERCENTAGE' : 'FIXED',
    discountValue: discount > 0 ? String(discount) : '',
    remarks: tx.remarks ?? '',
    cancelled: tx.paymentStatus === 'CANCELLED',
  };
}

/** What has been paid on an order: the sum of its payments (or the stored amount for an order without payment records). */
export function paidOn(tx: Pick<TxView, 'payments' | 'amountPaid'>): number {
  return tx.payments.length > 0 ? round2(tx.payments.reduce((n, p) => n + p.amount, 0)) : tx.amountPaid;
}

/** Live totals while editing (invalid or empty rows count as zero). */
export function previewOrderEdit(form: OrderEditForm, business: ResolvedBusiness, tx: TxView): CalculationResult {
  const items = readLines(form.lines)
    .filter((l) => l.quantity !== null && l.quantity > 0 && l.price !== null && l.price >= 0)
    .map((l) => ({ quantity: l.quantity as number, unitSellingPrice: l.price as number, unitCost: l.line.unitCost }));
  return calculate(
    { method: business.profitMethod, marginPercent: business.marginPercent, useUnitCostIfAvailable: business.useUnitCostIfAvailable },
    items,
    form.discountType,
    parseNumber(form.discountValue) ?? 0,
    paidOn(tx),
    form.cancelled ? 'CANCELLED' : 'PENDING',
  );
}

/** Validates the edit and builds the updated order document, ready to be saved. */
export function buildOrderEdit(form: OrderEditForm, tx: TxView, business: ResolvedBusiness): Result<TransactionInput> {
  const rows = readLines(form.lines);
  if (rows.length === 0) return { ok: false, error: 'Add at least one product.' };
  for (const r of rows) {
    if (r.line.name.trim() === '') return { ok: false, error: 'Every item needs a product name.' };
    if (r.quantity === null || !Number.isInteger(r.quantity) || r.quantity < 1) return { ok: false, error: `Enter a whole-number quantity of 1 or more for "${r.line.name.trim()}".` };
    if (r.price === null || r.price < 0) return { ok: false, error: `Enter a valid price for "${r.line.name.trim()}".` };
  }
  const discount = form.discountValue.trim() === '' ? 0 : parseNumber(form.discountValue);
  if (discount === null || discount < 0) return { ok: false, error: 'Enter a valid discount.' };
  if (form.discountType === 'PERCENTAGE' && discount > 100) return { ok: false, error: 'A percentage discount can be at most 100%.' };

  const paid = paidOn(tx);
  const calc = calculate(
    { method: business.profitMethod, marginPercent: business.marginPercent, useUnitCostIfAvailable: business.useUnitCostIfAvailable },
    rows.map((r) => ({ quantity: r.quantity as number, unitSellingPrice: r.price as number, unitCost: r.line.unitCost })),
    form.discountType,
    discount,
    paid,
    form.cancelled ? 'CANCELLED' : 'PENDING',
  );
  return {
    ok: true,
    value: {
      id: tx.id,
      orderNumber: tx.orderNumber,
      businessType: tx.businessType,
      customerName: tx.customerName,
      orderDateEpochMillis: tx.orderDateEpochMillis,
      discountType: form.discountType,
      discountPercentage: form.discountType === 'PERCENTAGE' ? discount : 0,
      discountAmount: calc.discountAmount,
      grossSales: calc.grossSales,
      netSales: calc.netSales,
      totalProductCost: calc.totalProductCost,
      estimatedProfit: calc.estimatedProfit,
      paymentStatus: calc.resolvedStatus,
      amountPaid: round2(paid),
      outstandingBalance: calc.outstandingBalance,
      paymentNotes: tx.paymentNotes ?? '',
      remarks: form.remarks.trim(),
      lineItems: rows.map((r) => ({
        productId: Number(r.line.productId) || 0,
        productName: r.line.name.trim(),
        quantity: r.quantity as number,
        unitSellingPrice: r.price as number,
        unitCost: r.line.unitCost,
        lineSubtotal: round2((r.quantity as number) * (r.price as number)),
      })),
      payments: tx.payments.map((p) => ({ ...p })),
    },
  };
}
