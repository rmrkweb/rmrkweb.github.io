import { describe, expect, it } from 'vitest';
import type { ResolvedBusiness } from './businesses';
import { buildOrderEdit, orderToEditForm, paidOn, previewOrderEdit } from './orderBuilder';
import type { TxView } from '../types';

const business: ResolvedBusiness = {
  key: 'ENGRAVING', name: 'Engraving', orderPrefix: 'ENG', colorHex: '#00B8F0', iconKey: null, isActive: true,
  sortOrder: 0, profitMethod: 'UNIT_COST', marginPercent: 0, useUnitCostIfAvailable: false,
};
const NOW = Date.UTC(2026, 9, 23, 4);
const tx = (over: Partial<TxView> = {}): TxView =>
  ({
    id: 'tx-1', userId: 'u', orderNumber: 'ENG-2026-0001', businessType: 'ENGRAVING', businessKey: 'ENGRAVING', customerName: 'Ana Cruz',
    orderDateEpochMillis: NOW, discountType: 'PERCENTAGE', discountPercentage: 10, discountAmount: 20, grossSales: 200, netSales: 180,
    totalProductCost: 80, estimatedProfit: 100, paymentStatus: 'PARTIALLY_PAID', amountPaid: 100, outstandingBalance: 80, paymentNotes: 'n',
    remarks: 'Rush', lineItems: [{ productId: 5, productName: 'Mug', quantity: 2, unitSellingPrice: 100, unitCost: 40, lineSubtotal: 200 }],
    payments: [{ amount: 100, paymentDateEpochMillis: NOW, paymentMethod: 'Cash', referenceNumber: '', notes: 'Initial' }], lineItemsSummary: '', ...over,
  }) as TxView;

describe('orderToEditForm', () => {
  it('starts from what the order has', () => {
    const f = orderToEditForm(tx());
    expect(f).toEqual({
      lines: [{ productId: '5', name: 'Mug', quantity: '2', unitPrice: '100', unitCost: 40 }],
      discountType: 'PERCENTAGE', discountValue: '10', remarks: 'Rush', cancelled: false,
    });
    expect(orderToEditForm(tx({ discountType: 'FIXED', discountPercentage: 0, discountAmount: 25 })).discountValue).toBe('25');
    expect(orderToEditForm(tx({ paymentStatus: 'CANCELLED' })).cancelled).toBe(true);
    expect(orderToEditForm(tx({ lineItems: [{ productId: 0, productName: 'Custom', quantity: 1, unitSellingPrice: 5, unitCost: 0, lineSubtotal: 5 }] })).lines[0].productId).toBe('');
  });
});

describe('buildOrderEdit', () => {
  it('recalculates the totals but keeps the order, customer, date and payments', () => {
    const f = orderToEditForm(tx());
    f.lines[0].quantity = '3';
    f.remarks = ' Updated ';
    const r = buildOrderEdit(f, tx(), business);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.value).toMatchObject({
      id: 'tx-1', orderNumber: 'ENG-2026-0001', customerName: 'Ana Cruz', orderDateEpochMillis: NOW, businessType: 'ENGRAVING',
      grossSales: 300, discountAmount: 30, netSales: 270, totalProductCost: 120, estimatedProfit: 150, amountPaid: 100,
      outstandingBalance: 170, paymentStatus: 'PARTIALLY_PAID', remarks: 'Updated', paymentNotes: 'n',
    });
    expect(r.value.payments).toEqual(tx().payments);
    expect(r.value.lineItems[0]).toMatchObject({ productId: 5, quantity: 3, lineSubtotal: 300, unitCost: 40 });
  });

  it('becomes paid when the new total is covered by the payments, and pending again when a payment is not enough', () => {
    const f = orderToEditForm(tx());
    f.lines[0].quantity = '1'; // 100 less 10% = 90, paid 100
    const paid = buildOrderEdit(f, tx(), business);
    expect(paid.ok && paid.value).toMatchObject({ netSales: 90, outstandingBalance: 0, paymentStatus: 'PAID' });
    const none = buildOrderEdit(orderToEditForm(tx({ payments: [], amountPaid: 0 })), tx({ payments: [], amountPaid: 0 }), business);
    expect(none.ok && none.value).toMatchObject({ amountPaid: 0, paymentStatus: 'PENDING' });
  });

  it('cancels and un-cancels an order', () => {
    const f = orderToEditForm(tx());
    f.cancelled = true;
    const c = buildOrderEdit(f, tx(), business);
    expect(c.ok && c.value.paymentStatus).toBe('CANCELLED');
    const back = buildOrderEdit({ ...f, cancelled: false }, tx({ paymentStatus: 'CANCELLED' }), business);
    expect(back.ok && back.value.paymentStatus).toBe('PARTIALLY_PAID');
  });

  it('uses the payments as the paid amount, and the stored amount when there are no payment records', () => {
    expect(paidOn(tx({ payments: [{ amount: 30, paymentDateEpochMillis: 1, paymentMethod: 'Cash', referenceNumber: '', notes: '' }, { amount: 20.5, paymentDateEpochMillis: 2, paymentMethod: 'GCash', referenceNumber: '', notes: '' }], amountPaid: 999 }))).toBe(50.5);
    expect(paidOn(tx({ payments: [], amountPaid: 75 }))).toBe(75);
  });

  it('rejects bad input with the same messages as a new order', () => {
    const base = orderToEditForm(tx());
    expect(buildOrderEdit({ ...base, lines: [{ productId: '', name: '', quantity: '', unitPrice: '', unitCost: 0 }] }, tx(), business)).toEqual({ ok: false, error: 'Add at least one product.' });
    expect(buildOrderEdit({ ...base, lines: [{ ...base.lines[0], quantity: '1.5' }] }, tx(), business).ok).toBe(false);
    expect(buildOrderEdit({ ...base, lines: [{ ...base.lines[0], unitPrice: '-1' }] }, tx(), business).ok).toBe(false);
    expect(buildOrderEdit({ ...base, discountValue: '120' }, tx(), business)).toEqual({ ok: false, error: 'A percentage discount can be at most 100%.' });
    expect(buildOrderEdit({ ...base, discountType: 'FIXED', discountValue: 'abc' }, tx(), business)).toEqual({ ok: false, error: 'Enter a valid discount.' });
  });

  it('previews with the amount already paid', () => {
    const preview = previewOrderEdit(orderToEditForm(tx()), business, tx());
    expect(preview).toMatchObject({ netSales: 180, outstandingBalance: 80, resolvedStatus: 'PARTIALLY_PAID' });
  });
});
